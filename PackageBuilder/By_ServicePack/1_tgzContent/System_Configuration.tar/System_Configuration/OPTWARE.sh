#!/bin/sh
# Retrieving Form Variables... use as $GUI_varname
folder="System_Configuration"
Scriptname="OPTWARE"

cd /proto/SxM_webui/fpkmgr/fpks/$folder
if [ -f /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars ] ;then
. /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars
fi

if  [ -f "/opt/bin/ipkg" ] || [ -e  /etc/ld.so.conf ] ; then
   echo "<br><br><b>Manage OPTWARE Packages : </b>"
   echo "<a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=LIST_AVAILABLE>List of Available packages</a>"
   echo "<a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=LIST_INSTALLED>List of installed packages</a>"
   echo "<br>"

 if  [ "$1" = "LIST_AVAILABLE" ];then
  echo "<b> List of Installed Ipkg packages </b>"
   /opt/bin/ipkg update
  export IFS=�
   /opt/bin/ipkg list|sed -e 's/ - /�/g'|while read name version descr
  do
  echo "<b>$name</b> - $version - $descr"
  done
 fi

 if  [ "$1" = "LIST_INSTALLED" ];then
   echo "<b> List of Installed Ipkg packages </b>"
   export IFS=�
   /opt/bin/ipkg list_installed|sed -e 's/ - /�/g'|while read name version descr
   do
   echo "<b>$name</b> - $version - $descr"
   done


 fi
  
  
fi

