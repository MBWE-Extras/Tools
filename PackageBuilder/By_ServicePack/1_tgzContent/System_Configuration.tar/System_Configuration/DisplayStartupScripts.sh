echo "<b>List of startup Scripts in /etc/init.d :</b>"
ls -l /etc/init.d/S??*
echo "<br>"

echo "<b>List of startup Scripts in /opt/etc/init.d :</b>"
ls -l /opt/etc/init.d/S??*
