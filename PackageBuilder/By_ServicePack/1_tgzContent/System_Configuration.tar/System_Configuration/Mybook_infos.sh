folder="System_Configuration"
Scriptname="Mybook_infos"

cd /proto/SxM_webui/fpkmgr/fpks/$folder

if [ -e /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars ] ;then
. /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars
fi

FLAG=$1

cronfile="/opt/var/cron/crontabs/root"
    
echo "<b> Mybook Infos</b>"
  echo -n " <table><tr>"

  echo -n " <td><a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=ProcessInfo> Process </a></td> "
  echo -n " <td><a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=DiskInfo> Disk </a></td> "
  echo -n " <td><a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=NetworkInfo> Network </a></td> "
  echo -n " <td><a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=Performance> Performance </a></td> "
  echo -n " <td><a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=Leds> Leds </a></td> "
    
  echo -n " </tr></table><br><br>"

if ( [ "$FLAG" = "LedsON" ] ) ;  then
  echo 255>/sys/class/leds/oxnas-wd810-leds:sw/brightness
  if [ -e  /opt/etc/init.d/S99LedsOff.sh ];then
    rm /opt/etc/init.d/S99LedsOff.sh
  fi
  FLAG="Leds"
fi

if ( [ "$FLAG" = "LedsOFF" ] ) ;  then
  echo 192>/sys/class/leds/oxnas-wd810-leds:sw/brightness
  cp /proto/SxM_webui/fpkmgr/fpks/$folder/bin/S99LedsOff /opt/etc/init.d/S99LedsOff.sh
  chmod a+rx /opt/etc/init.d/S99LedsOff.sh
  FLAG="Leds"
fi

if ( [ "$FLAG" = "SET_LED_Schedule" ] ) ;  then


   CMDLINE="echo 255>/sys/class/leds/oxnas-wd810-leds:sw/brightness"
   CRONTAB=`cat $cronfile|grep -v oxnas-wd810-led`
   echo "$CRONTAB" >$cronfile


 if [ "$GUI_ledScheduleEnabled" = "on" ];then
   CMDLINEON="echo 255>/sys/class/leds/oxnas-wd810-leds:sw/brightness"
   CMDLINEOFF="echo 192>/sys/class/leds/oxnas-wd810-leds:sw/brightness"

   SchedLine="0 $GUI_ledstarthour * * * $CMDLINEON"
   echo "$SchedLine">>$cronfile

   SchedLine="0 $GUI_ledstophour * * * $CMDLINEOFF"
   echo "$SchedLine">>$cronfile
 fi


  killall cron
  /opt/etc/init.d/S10cron start
       
       

 FLAG="Leds"
fi

if ( [ "$FLAG" = "Leds" ] ) ;  then

echo -n "Led Status : "
test=`cat /sys/class/leds/oxnas-wd810-leds:sw/brightness`
if [ "$test" = "255" ];then
  echo "<b> ON</b>"

else
   if [ "$test" = "192" ];then
     echo "<b> OFF</b>"
   else 
     echo " unknown"
   fi
fi

  echo " <a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=LedsON> Turn  ON </a> "
  echo " <a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=LedsOFF> Turn OFF </a>"

  echo "Schedule : "
  echo -n "<form action=/fpkmgr/index.php method=post>"
  
test=`cat "$cronfile"|grep -c "oxnas-"`

if [ "$test" = "0" ];then
  echo "<input type=checkbox name=ledScheduleEnabled> Enable Led Schedule"
else
  echo "<input type=checkbox checked name=ledScheduleEnabled> Enable Led Schedule"
fi

ScriptKey="echo 255>"
planned=`cat "$cronfile"|grep -c "$ScriptKey"`

  if [ "$planned" = "1" ];then
    H=`cat $cronfile|grep "$ScriptKey"|cut -f2 -d" "`
  else
    H="0"
  fi
  

  echo -n "Light on at <select name=ledstarthour>"
  echo -n "<option>$H</option>"
  echo -n "<option>0</option>" 
  echo -n "<option>1</option>" 
  echo -n "<option>2</option>" 
  echo -n "<option>3</option>" 
  echo -n "<option>4</option>"  
  echo -n "<option>5</option>" 
  echo -n "<option>6</option>" 

  echo -n "<option>7</option>" 
  echo -n "<option>8</option>" 
  echo -n "<option>9</option>" 
  echo -n "<option>10</option>" 
  echo -n "<option>11</option>"
  echo -n "<option>12</option>"
  echo -n "<option>13</option>" 
  echo -n "<option>14</option>" 
  echo -n "<option>15</option>" 
  echo -n "<option>16</option>" 
  echo -n "<option>17</option>" 
  echo -n "<option>18</option>" 
  echo -n "<option>19</option>" 
  echo -n "<option>20</option>" 
  echo -n "<option>21</option>" 
  echo -n "<option>22</option>" 
  echo -n "<option>23</option>"
  echo -n "<option>24</option>"

  echo -n "</select>"
  echo "h"

ScriptKey="echo 192>"

  planned=`cat "$cronfile"|grep -c "$ScriptKey"`

  if [ "$planned" = "1" ];then
      H=`cat $cronfile|grep "$ScriptKey"|cut -f2 -d" "`
  else
      H="0"
  fi
              
  echo -n "Light off at <select name=ledstophour>"
  echo -n "<option>$H</option>"
  echo -n "<option>0</option>"
  echo -n "<option>1</option>"
  echo -n "<option>2</option>"
  echo -n "<option>3</option>"
  echo -n "<option>4</option>"
  echo -n "<option>5</option>"
  echo -n "<option>6</option>"

  echo -n "<option>7</option>"
  echo -n "<option>8</option>"
  echo -n "<option>9</option>"
  echo -n "<option>10</option>"
  echo -n "<option>11</option>"
  echo -n "<option>12</option>"
  echo -n "<option>13</option>"
  echo -n "<option>14</option>"
  echo -n "<option>15</option>"
  echo -n "<option>16</option>"
  echo -n "<option>17</option>"
  echo -n "<option>18</option>"
  echo -n "<option>19</option>"
  echo -n "<option>20</option>"
  echo -n "<option>21</option>"
  echo -n "<option>22</option>"
  echo -n "<option>23</option>"
  echo -n "<option>24</option>"

  echo -n "</select>"
  echo "h"


  echo -n "<input type=hidden name=ACTION value=ExecScript>"
  echo -n "<input type=hidden name=ScriptFolder value=$folder>"
  echo -n "<input type=hidden name=ScriptName value=$Scriptname>"
  echo -n "<input type=hidden name=Params value=SET_LED_Schedule>"
  echo -n "<input type=submit value='Modify'>"
  echo -n "</form>"


fi

if ( [ "$FLAG" = "LedsON" ] ) ;  then
echo 192>/sys/class/leds/oxnas-wd810-leds:sw/brightness
fi





if ( [ "$FLAG" = "Performance" ] ) ;  then
Temp=`/usr/sbin/smartctl -d ata -A /dev/sda|grep Temperature|cut -f2 -d "-"`
TotalMem=`cat /proc/meminfo |grep MemTotal:|cut -f2 -d ":"`

FreeMem=`cat /proc/meminfo | grep MemFree:|cut -f2 -d ":"`
SysUpTime1=`uptime |cut -f1 -d ","`
SysUpTime2=`uptime |cut -f2 -d ","`
SysUpTime="$SysUpTime1 $SysUpTime2"


Minute1_LoadAverage=`uptime |cut -f3 -d ","|cut -f2 -d ":"`
Minute5_LoadAverage=`uptime |cut -f4 -d ","`
Minute15_LoadAverage=`uptime |cut -f5 -d ","` 

echo -n "<br> Sys Up Time : $SysUpTime "
echo -n "<br> Temperature : <b>$Temp</b> � Celsius" 
echo -n "<br> Total Memory : <b>$TotalMem</b> "
echo -n "<br> Free Memory : <b>$FreeMem</b> "
echo -n "<br> CPU Load during last Minute: <b>$Minute1_LoadAverage</b> "
echo -n "<br> CPU Load during last 5 Minutes: <b>$Minute5_LoadAverage</b> "
echo -n "<br> CPU Load during last 15 Minutes: <b>$Minute15_LoadAverage</b> "

if [ "$GUI_Graph" = "True" ] ;then
  echo "$Temp,$TotalMem,$FreeMem,$Minute1_LoadAverage,$Minute5_LoadAverage,$Minute15_LoadAverage">>/proto/SxM_webui/fpkmgr/fpks/$folder/perfdata.log
else
  echo "$Temp,$TotalMem,$FreeMem,$Minute1_LoadAverage,$Minute5_LoadAverage,$Minute15_LoadAverage">/proto/SxM_webui/fpkmgr/fpks/$folder/perfdata.log
fi
echo "<br>Performance History : <br>"
cat /proto/SxM_webui/fpkmgr/fpks/$folder/perfdata.log

echo -n "<html><head>"
echo -n "<meta http-equiv=\"refresh\" content=\"15;URL=/fpkmgr/index.php?SourcePage=Mybook_Mgr&ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=Performance&Graph=True\">"
echo -n "</head><body></html>"
 
fi


if ( [ "$FLAG" = "ProcessInfo" ] ) ;  then
ps -ef
fi

if ( [ "$FLAG" = "DiskInfo" ] ) ;  then
  echo "<br><b> Disk Usage : </b><br><br><br>"
  df -h|sed 's/ /\&nbsp;/g'
fi

if ( [ "$FLAG" = "NetworkInfo" ] ) ;  then
  echo "<br><b>Network  Interfaces </b><br><br>"
  /sbin/ifconfig -a|sed 's/ /\&nbsp;/g'
  echo "<br><b>Routing Table </b><br><br>"
  netstat -nr|sed 's/ /\&nbsp;/g'

  echo "<br><b>Ports in use </b><br><br>"
  netstat -an|grep -i list|sed 's/ /\&nbsp;/g'

  
fi

if ( [ "$FLAG" = "FilesInUse" ] ) ;  then
 echo "<br><b> Internal Files in use :</b><br><br>"
lsof |grep /shares/internal

echo "<br><br><b> External Files in use :</b><br><br>"
lsof |grep /shares/external |sed 's/ /\&nbsp;/g'


fi
