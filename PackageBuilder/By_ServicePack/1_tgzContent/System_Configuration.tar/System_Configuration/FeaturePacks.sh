folder="System_Configuration"
Scriptname="FeaturePacks"

cd /proto/SxM_webui/fpkmgr/fpks/$folder
if [ -f /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars ] ;then
 . /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars
fi


# Checking if a parameter has been passed to the script
if [ "$1" = "" ];then
  echo "<b> Feature Packs Management : </b>"

 
   echo "<br> <a href=\"/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=FP_INSTALL_MAIN\">Install a feature Pack from URL</a>"
   if [ -f /tnmtna ];then
   echo "<br> <a href=\"/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=GEN_FP_SELECT\">GFP</a>"
   fi
 
fi

RTP=TRUE


if  [  "$1" = "FP_INSTALL_MAIN" ];then
  echo "<b> Install Feature Pack from url : </b>"
    
  echo "<form action=/fpkmgr/index.php method=post>"
  echo "<input type=hidden name=ACTION value=ExecScript>"
  echo "<input type=hidden name=ScriptFolder value=$folder>"
  echo "<input type=hidden name=ScriptName value=$Scriptname>"
        
  echo "<input type=hidden name=Params value=FP_INSTALL_FEATURE>"
  echo "Add feature Pack from url : <input type=text name=FeatureURL value=http://><input type=submit value=GET>"
  echo "</form>"
                  
fi

if  [  "$1" = "FP_INSTALL_FEATURE" ];then
 
   Feature_URL=$GUI_Feature_URL 
   Feature_FILE=${GUI_FeatureURL##*/} 
   Feature_basename=${Feature_FILE%%.*} 
   Feature_extension=${Feature_FILE#*.} 
         
   echo "Installing feature <b>$Feature_basename</b>: "
 
   VALID_FP="FALSE"                           

   if [ -e "/tmp/$Feature_basename.tar" ] ;then
            rm "/tmp/$Feature_basename.tar"
   fi
   wget $GUI_FeatureURL -O "/tmp/$Feature_basename.tar"  >/dev/nul 2>&1

   if [ -e "/tmp/$Feature_basename.tar" ];then
       cd /tmp
       test=`tar -tf $Feature_basename.tar|grep -c _info`
       if [ ! "$test" = "0" ];then
         VALID_FP="TRUE"
       else
         echo "this is not a valid Feature pack url : <br>"
         echo "$GUI_FeatureURL"
         if [ -e "/tmp/$Feature_basename.tar" ];then
            rm "/tmp/$Feature_basename.tar"
         fi
       fi
   fi

   if [ "$VALID_FP" = "TRUE" ];then
                       
      if [ ! -d "/proto/SxM_webui/fpkmgr/fpks/$Feature_basename" ];then
         mkdir  "/proto/SxM_webui/fpkmgr/fpks/$Feature_basename"
      fi

      cd "/proto/SxM_webui/fpkmgr/fpks"
      tar -xf /tmp/$Feature_basename.tar  
                                       
      rm  /tmp/$Feature_basename.tar
      if [ -e  "/proto/SxM_webui/fpkmgr/fpks/$Feature_basename/_install" ];then
         sh /proto/SxM_webui/fpkmgr/fpks/$Feature_basename/_install
         if [ ! -f /tnmtna ];then
           rm /proto/SxM_webui/fpkmgr/fpks/$Feature_basename/_install
         fi
                                  
      fi
                                                
      echo $Feature_basename Installation complete
   fi

fi
  


if  [  "$1" = "GEN_FP_SELECT" ];then
  echo "<b> Which Feature pack do you want to generate ? : </b>"

  echo -n "<form action=/fpkmgr/index.php method=post>"
  echo -n "<Select name=SelectedFeature>"
  for f in /proto/SxM_webui/fpkmgr/fpks/* ; do
   [ -d $f ] && echo -n "<Option value=${f##*/}>${f##*/}</option>"
  done

  echo -n "</select>"
   
  echo -n "<input type=hidden name=ACTION value=ExecScript>"
  echo -n "<input type=hidden name=ScriptFolder value=$folder>"
  echo -n "<input type=hidden name=ScriptName value=$Scriptname>"
  echo -n "<input type=hidden name=Params value=TYPE_FP_INFO>"
  echo -n "<input type=submit value='Next'>"
  echo -n "</form>"

fi

if  [ "$1" = "TYPE_FP_INFO" ];then
  echo " Please enter  <b>$GUI_SelectedFeature</b> Feature Pack information :"
  if [  -e /proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/_info ];then
  .  /proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/_info
  fi

  echo -n "<form action=/fpkmgr/index.php method=post>"
  echo -n "<br>Version : <input type=text name=FP_VERSION value=$FP_VERSION>"
#  echo -n "<br><br>Update Check info url : (url of _CheckUpdate file) : "
  
#  echo -n "<br> <input type=text size=50 name=FP_CONTROLURL value=\"$FP_CONTROLURL\">"
   
  echo -n "<input type=hidden name=ACTION value=ExecScript>"
 echo  -n "<input type=hidden name=SelectedFeature value=$GUI_SelectedFeature>"
   
  echo -n "<input type=hidden name=ScriptFolder value=$folder>"
  echo -n "<input type=hidden name=ScriptName value=$Scriptname>"
  echo -n "<input type=hidden name=Params value=GEN_FEATURE_PACK>"
  echo -n "<br><input type=submit value='Generate Feature pack'>"
  echo -n "</form>"
              
 # rm /proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/*.log
                    
fi
                    
                    
                    

if  [ "$1" = "GEN_FEATURE_PACK" ];then
 echo " Generating $GUI_SelectedFeature Feature Pack"
 if [ ! -d  /proto/SxM_webui/fpkmgr/temp ];then
     mkdir "/proto/SxM_webui/fpkmgr/temp"
 fi
 rm /proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/*.log >/dev/nul 2>&1
 rm /proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/*.vars >/dev/nul 2>&1
 
 echo "FP_VERSION=$GUI_FP_VERSION">"/proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/_info"
# echo "FP_CONTROLURL=$GUI_FP_CONTROLURL">>"/proto/SxM_webui/fpkmgr/fpks/$GUI_SelectedFeature/_info"
 
 cd /proto/SxM_webui/fpkmgr/fpks
 tar --exclude=*.conf --exclude=*.uuid -cf /proto/SxM_webui/fpkmgr/temp/$GUI_SelectedFeature.tar $GUI_SelectedFeature

 echo " Feature Pack has been generated in <a href= /fpkmgr/temp/$GUI_SelectedFeature.tar>/proto/SxM_webui/fpkmgr/temp/$GUI_SelectedFeature.tar</a>"

fi
