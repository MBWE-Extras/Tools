#!/bin/sh
# Retrieving Form Variables... use as $GUI_varname
folder="System_Configuration"
Scriptname="EmailReport"
if  [ ! -e /usr/local/fpkmgr ] ;then
   mkdir "/usr/local/fpkmgr"
fi
if  [ ! -e /usr/local/fpkmgr/System_Configuration ] ;then
   mkdir "/usr/local/fpkmgr/System_Configuration"
fi

Email_ConfFile="/usr/local/fpkmgr/System_Configuration/Email.conf"

cd /proto/SxM_webui/fpkmgr/fpks/$folder

if [ -e /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars ] ;then
. /proto/SxM_webui/fpkmgr/fpks/$folder/$Scriptname.vars
fi

cronfile="/opt/var/cron/crontabs/root"
 
# setting default values
Email_SMTPServer=smtp.gmail.com
Email_Account=Myname@gmail.com
Email_Password=password
Email_Activated="Nothing"
Email_Mailto="DestinationAddress@hotmail.com"
Email_TLS="ON"
Email_Title="WhiteLight Mybook Status Report"

if ( [ "$1" = "SET_EMAIL_OPTIONS"    ] ) ;  then
   echo "Email_Activated=TRUE">$Email_ConfFile
   echo "Email_SMTPServer=$GUI_Email_SMTPServer">>$Email_ConfFile
   echo "Email_Account=$GUI_Email_Account">>$Email_ConfFile
   echo "Email_Password=$GUI_Email_Password">>$Email_ConfFile
   echo "Email_Mailto=$GUI_Email_Mailto">>$Email_ConfFile
   echo "Email_TLS=$GUI_Email_TLS">>$Email_ConfFile
#   echo "Email_Title=$GUI_Email_Title">>$Email_ConfFile
fi

if ( [ "$1" = "EMAILREPORT_Activate" ] ) ;  then
   echo "Email_Activated=TRUE">$Email_ConfFile
   echo "Email_SMTPServer=$Email_SMTPServer">>$Email_ConfFile
   echo "Email_Account=$Email_Account">>$Email_ConfFile
   echo "Email_Password=$Email_Password">>$Email_ConfFile
   echo "Email_Mailto=$Email_Mailto">>$Email_ConfFile
   echo "Email_TLS=$Email_TLS">>$Email_ConfFile
#   echo "Email_Title=$Email_Title">>$Email_ConfFile
fi

if [ -e $Email_ConfFile ] ;then
    Email_Activated=`cat  $Email_ConfFile|grep Email_Activated|cut -f2 -d "="`
    Email_SMTPServer=`cat $Email_ConfFile|grep Email_SMTPServer|cut -f2 -d "="`
    Email_Account=`cat  $Email_ConfFile|grep Email_Account|cut -f2 -d "="`
    Email_Password=`cat  $Email_ConfFile|grep Email_Password|cut -f2 -d "="`
    Email_Mailto=`cat  $Email_ConfFile|grep Email_Mailto|cut -f2 -d "="`
    Email_TLS=`cat  $Email_ConfFile|grep Email_TLS|cut -f2 -d "="`
#    Email_Title=`cat  $Email_ConfFile|grep Email_Titl|cut -f2 -d "="`
fi

if ( [ "$1" = "EMAILREPORT_Disable" ] ) ;  then

   CMDLINE="sh /proto/SxM_webui/fpkmgr/fpks/$folder/EmailReport.sh SEND_REPORT PLANNED"
   CRONTAB=`cat $cronfile|grep -v EmailReport`
   echo "$CRONTAB" >$cronfile

   killall cron
   /opt/etc/init.d/S10cron start

   echo "Email_Activated=Nothing">$Email_ConfFile
   echo "Email_SMTPServer=$Email_SMTPServer">>$Email_ConfFile
   echo "Email_Account=$Email_Account">>$Email_ConfFile
   echo "Email_Password=$Email_Password">>$Email_ConfFile
   echo "Email_Mailto=$Email_Mailto">>$Email_ConfFile
   echo "Email_TLS=$Email_TLS">>$Email_ConfFile
#   echo "Email_Title=$Email_Title">>$Email_ConfFile

fi

if ( [ "$1" = "MODIF_SCHEDULE" ] ) ;  then

          CMDLINE="sh /proto/SxM_webui/fpkmgr/fpks/$folder/EmailReport.sh SEND_REPORT PLANNED"
          CRONTAB=`cat $cronfile|grep -v EmailReport`
	  echo "$CRONTAB" >$cronfile
      

    if [ "$GUI_Sched_Status"  = "Enabled" ] ;then
        if [ "$GUI_Start_Hour" = "" ] ;then GUI_Start_Hour=1 ;fi
        if [ "$GUI_DayOfWeek" = "" ] ;then GUI_DayOfWeek=* ;fi
        SchedLine="0 $GUI_Start_Hour * * $GUI_DayOfWeek $CMDLINE"
	echo "$SchedLine">>$cronfile
    fi

         killall cron
         /opt/etc/init.d/S10cron start
                      
fi


if ( [ "$1" = "SEND_REPORT" ] ) ;  then

  echo "From: \"MybookReport\"<$Email_Account>" > /tmp/mymailinput
  echo "To: $Email_Mailto" >> /tmp/mymailinput
  echo "Subject: $Email_Title" >> /tmp/mymailinput
  echo "MIME-Version: 1.0  " >> /tmp/mymailinput
  echo "Content-Type: text/html; charset=iso-8859-15  " >> /tmp/mymailinput
  echo "" >> /tmp/mymailinput

  for f in /proto/SxM_webui/fpkmgr/fpks/* ; do
   if [ -d $f ];then

      if [ -e /proto/SxM_webui/fpkmgr/fpks/${f##*/}/Report ];then
        sh  /proto/SxM_webui/fpkmgr/fpks/${f##*/}/Report "$2">> /tmp/mymailinput 2>&1
      fi
   fi
  done

# "send email, depending on smtp provider ... "
rm /proto/SxM_webui/fpkmgr/fpks/$folder/ssmtpd.log


EmailSent="FALSE"
if [ "$Email_TLS" = "ON"  ];then
  echo "account mailaccount">/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "host $Email_SMTPServer">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "port 587">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "timeout 5">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "auth on">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "tls_certcheck off">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "tls on">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "user $Email_Account">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "password $Email_Password">>/usr/local/fpkmgr/System_Configuration/mailaccount.conf
  echo "Sending Email ,using TLS , port 587 and msmtp ... "  >/proto/SxM_webui/fpkmgr/fpks/$folder/ssmtpd.log 2>&1
  /usr/sbin/msmtp  -C /usr/local/fpkmgr/System_Configuration/mailaccount.conf -a mailaccount  -f $Email_Account $Email_Mailto < /tmp/mymailinput  >>/proto/SxM_webui/fpkmgr/fpks/$folder/ssmtpd.log 2>&1
  rm /usr/local/fpkmgr/System_Configuration/mailaccount.conf

  EmailSent="TRUE"
fi

if [ "$EmailSent" = "FALSE" ];then
  echo "Sending Email using and mini_sendmail : "  >/proto/SxM_webui/fpkmgr/fpks/$folder/ssmtpd.log 2>&1
  
  cat /tmp/mymailinput | /usr/sbin/mini_sendmail -f$Email_Account -t -s$Email_SMTPServer -U$Email_Account -P$Email_Password -v  >>/proto/SxM_webui/fpkmgr/fpks/$folder/ssmtpd.log 2>&1
fi



fi


if [ "$Email_Activated" = "TRUE" ];then
  echo " <b>Email Configuration : </b>"
  echo -n " Email Report is currently Enabled."  
  echo  "<a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=EMAILREPORT_Disable>(Disable)</a>"
 

  echo -n "<form action=/fpkmgr/index.php method=post>"
#  echo "Email Title : <input type=text name=Email_Title value=\"$Email_Title\">"
  echo "Email Smtp Server : <input type=text name=Email_SMTPServer value=$Email_SMTPServer>"
  echo "Email Account : <input type=text name=Email_Account size=35 value=$Email_Account>"
  echo "Email Password : <input type=password name=Email_Password size=20 value=$Email_Password>"
  echo "Send report to : <input type=text name=Email_Mailto size=35 value=$Email_Mailto>"

  echo -n " mode TLS + port587 (gmail)" 

  echo -n "<Select name=Email_TLS>"
  if [ "$Email_TLS" = "ON" ];then
    echo -n "  <Option Selected >ON</option>"
    echo -n "  <Option>OFF</option>"
  else
    echo -n "  <Option>ON</option>"
    echo -n "  <Option Selected>OFF</option>"
  fi

  echo -n "</Select><br>"

  echo -n "<input type=hidden name=ACTION value=ExecScript>"
  echo -n "<input type=hidden name=ScriptFolder value=$folder>"
  echo -n "<input type=hidden name=ScriptName value=$Scriptname>"
  echo -n "<input type=hidden name=Params value=SET_EMAIL_OPTIONS>"
  echo -n "<input type=submit value='Modify'>"
  echo -n "</form>"


 echo -n "<B>Schedule Email reports :</B>"


 ScriptKey="EmailReport.sh"
 planned=`cat $cronfile|grep -c $ScriptKey`
 if [ "$planned" = "1" ];then
  H=`cat $cronfile|grep $ScriptKey|cut -f2 -d" "`
  D=`cat $cronfile|grep $ScriptKey|cut -f5 -d" "`
  if [ "$D" = "7" ];then  D_Disp="Sunday" ;fi
  if [ "$D" = "1" ];then  D_Disp="Monday"  ;fi
  if [ "$D" = "2" ];then  D_Disp="Tuesday"  ;fi
  if [ "$D" = "3" ];then  D_Disp="Wednesday"  ;fi
  if [ "$D" = "4" ];then  D_Disp="Thirsday"  ;fi
  if [ "$D" = "5" ];then  D_Disp="Friday"  ;fi
  if [ "$D" = "6" ];then  D_Disp="Saturday"  ;fi
  if [ "$D" = "*" ];then  D_Disp="EachDay"  ;fi

else
   H=""; D="";D_Disp=""
fi


echo -n "<form action=/fpkmgr/index.php method=post>"

echo -n "<Select name=Sched_Status>"
if [ "$planned" = "1" ];then
  echo -n "  <Option value=Enabled selected>Enabled</option>"
else
  echo -n "  <Option value=Disabled selected>Disabled</option>"
fi
echo -n "  <Option value=Disabled>Disabled</option>"
echo -n "  <Option value=Enabled>Enabled</option>"

echo -n "</select>"
echo -n " Start at "
echo -n "<Select name=Start_Hour>"
echo -n "  <Option Selected value=$H>$H</option>"
echo -n "  <Option value=0>00</option> <Option value=1>01</option> <Option value=2>02</option> <Option value=3>03</option>"
echo -n "  <Option value=4>04</option> <Option value=5>05</option> <Option value=6>06</option> <Option value=7>07</option>"
echo -n "  <Option value=8>08</option> <Option value=9>09</option>"

echo -n "  <Option value=10>10</option> <Option value=11>11</option> <Option value=12>12</option> <Option value=13>13</option>"
echo -n "  <Option value=14>14</option> <Option value=15>15</option> <Option value=16>16</option> <Option value=17>17</option>"
echo -n "  <Option value=18>18</option> <Option value=19>19</option>"

echo -n "  <Option value=20>20</option> <Option value=21>21</option> <Option value=22>22</option> <Option value=23>23</option>"
echo -n "</select>"
echo -n " H00 , "
echo -n "<Select name=DayOfWeek>"

echo -n "  <Option Selected value=$D>$D_Disp</option>"
echo -n "  <Option value=7>Sunday</option>"
echo -n "  <Option value=1>Monday</option>"
echo -n "  <Option value=2>Tuesday</option>"
echo -n "  <Option value=3>Wednesday</option>"
echo -n "  <Option value=4>Thursday</option>"
echo -n "  <Option value=5>Friday</option>"
echo -n "  <Option value=6>Saturday</option>"

echo -n "  <Option value=*>EachDay</option>"
echo -n "</select>"

echo -n "of each week."

echo -n "<input type=hidden name=SourcePage value=Mybook_Mgr><input type=hidden name=ACTION value=ExecScript>"
echo -n "<input type=hidden name=ScriptFolder value=$folder>"
echo -n "<input type=hidden name=ScriptName value=$Scriptname>"
echo -n "<input type=hidden name=Params value=MODIF_SCHEDULE>"
echo -n "<input type=submit value='Modify'>"
echo -n "</form>"

echo -n "<B>Email report Actions  :</B><br>"

echo "<a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=SEND_REPORT>Send Report Now...</a>"


echo  "<br><a target=newwindow href=/fpkmgr/fpks/$folder/ssmtpd.log>view last email log</a>"

 


else

  echo -n " Email Report is currently disabled."  
  echo "<a href=/fpkmgr/index.php?ACTION=ExecScript&ScriptFolder=$folder&ScriptName=$Scriptname&Params=EMAILREPORT_Activate>(Activate)</a>"
fi
